﻿function ShowAllShortDesc(id) {
    // Remove all short Desc
    $('.product-short-desc').removeClass('product-short-desc-show', 500);
    $('#product-short-desc-' + id).addClass('product-short-desc-show', 500);
    $('#product-short-desc-' + id + ' .view-less').show();
    return false;
}

function HideAllShortDesc(id) {
    $('#product-short-desc-' + id).removeClass('product-short-desc-show', 500);
    $('#product-short-desc-' + id + ' .view-less').hide();
    return false;
}

    function ShowCollapsed(id) {
        if ($('#row-' + id).attr('is-collapsed') == "1") {
            $('#row-' + id).removeClass('row-collapsed', 500);
            $('#row-' + id).addClass('row-expanded', 500);

            $('#row-' + id).attr('is-collapsed', 0);
            $('#nav-' + id).html('<span>ÍT HƠN</span><br /><i class="fa fa-angle-up fa-2x"></i>')
            
        } else {
            $('#row-' + id).removeClass('row-expanded', 500);
            $('#row-' + id).addClass('row-collapsed', 500);

            $('#row-' + id).attr('is-collapsed', 1);
            $('#nav-' + id).html('<span>XEM THÊM</span><br /><i class="fa fa-angle-down fa-2x"></i>')
        }
    }


    function AddToCart(id, guid) {
        var qty = $('#add-to-cart-' + id + '-' + guid).val();
        $.ajax({
            type: "POST",
            url: "/ShoppingCart/AddToCart",
            data: { id: id, qty: qty },
            success: function(data) {
                $.sticky(data['AddToCartSuccess']);
                $('#cart-qty').text(data['CartTotalQty']);

                RefreshCartSumary();
            }
        });

    return false;
}
    
    function RemoveCartItem(id) {
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/RemoveFromCart",
            data: { id: id },
            success: function (data) {
                $.sticky('Xoá sản phẩm thành công.');
                RefreshAndShowCartSumary();
            }
        });
    }

    function RefreshCartSumary() {
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/CartSummary",
            success: function(sumary) {
                $('#cart-header').html(sumary);
                
            }
        });
    }
    function RefreshAndShowCartSumary() {
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/CartSummary",
            success: function (sumary) {
                $('#cart-header').html(sumary);
                $('#cart-header .cart-detail').addClass('display-block');
            }
        });
    }

    function EmptyCart() {
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/EmptyCart",
            success: function (data) {
                $.sticky('Làm trống giỏ thành công.');
                RefreshAndShowCartSumary();
                
            }
        });
    }

    function UpdateQty(id) {
        var qty = $('#qty-' + id).val();
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/UpdateCartCount",
            data: { id: id, cartCount: qty },
            success: function(data) {
                $.sticky(data.Message);
                RefreshAndShowCartSumary();
            }
    });
    }
    function MBUpdateQty(id, qty) {
        $.ajax({
            type: "GET",
            url: "/ShoppingCart/UpdateCartCount",
            data: { id: id, cartCount: qty },
            success: function (data) {
                $.sticky(data.Message);
                RefreshAndShowCartSumary();
            }
        });
    }

    function AddAllCartToWishList(user) {
        if (user == "" || user == null) {
            location.href = "/Account/Login";
        }
        $.ajax({
            type: 'Post',
            url: '/WishList/AddAllCartToWishList',
            success: function (data) {
                $.sticky(data);
            },
        });
    }
    
    function AddToWishList(id, user) {
        if (user == "" || user == null) {
            location.href = "/Account/Login";
        }
        $.ajax({
            type: 'Post',
            url: '/WishList/AddToWishList?productID=' + id,
            success: function(data) {
                $.sticky(data);
            },
        });
    }


    $('#cart-header').click(function (e) {
        if ($(e.target).hasClass('cart-header')) {
            $('#cart-header .cart-detail').toggleClass('display-block');
        }
//        $('#cart-qty').css('border-color', 'red');
    });

    $('.col-supports #help-customer').click(function (e) {
        if ($('.col-supports .help-topic-detail').hasClass('display-block') && !$(e.target).hasClass('help-topic-click')) {
            window.location.href = $('#help-customer a').attr('href');
        } else {
            $('.col-supports .help-topic-detail').addClass('display-block');
            $('#cart-header .cart-detail').removeClass('display-block');
            return false;
        }
        
        
    });


//$('.add-to-cart').click(function () {
    function AddToCartClick(guid) {
        $('.add-to-cart-box-wrraper').removeClass('display-block');
        $('#cart-box-wrraper-' + guid).addClass('display-block');
    };

        $("html, body").click(function (e) {
            if ($(e.target).hasClass('product-box')
                || $(e.target).hasClass('product-short-desc')
                || $(e.target).hasClass('view-more')) {

                return false;
            }
            $('.product-short-desc').removeClass('product-short-desc-show');
        });


       $("html, body").click(function (e) {
            
            if ($(e.target).hasClass('add-to-cart-click')) {
                return false;
            } else {
                $('.add-to-cart-box-wrraper').removeClass('display-block');
                return true;
            }
        });

        $("html, body").click(function (e) {
            
            if ($(e.target).hasClass('cart-detail-click')) {
                //$('#cart-header .cart-detail').addClass('display-block');
                return false;
            } else {
                $('#cart-header .cart-detail').removeClass('display-block');
                //$('#cart-qty').css('border-color', '#ccc');
                return true;
            }
        });
        
        $("html, body").click(function (e) {
            $('.col-supports .help-topic-detail').addClass('display-block');
            if ($(e.target).hasClass('help-topic-click')) {
                return false;
            } else {
                $('.col-supports .help-topic-detail').removeClass('display-block');
                return true;
            }
        });

        function LoadProductForRow(catId, productTake, sort, reload, productTagIds, noOfCol) {
            
            if (sort == null)
            {
                sort = $("#Sort").val();
            }

            var loadedProductIDs = [];
            if (reload == null || reload == false) {
                var loadedProductEles = $('#row-content-for-' + catId).find('div[product-id]');
                for (var index = 0; index < loadedProductEles.length; ++index) {
                    loadedProductIDs.push($(loadedProductEles[index]).attr('product-id'));
                }
            }
            else {
                $('#row-content-for-' + catId).html("");
            }
            $.ajax({
                type: 'Post',
                traditional:true ,
                url: LoadProductCategoryUrl,
                data: { categoryId: catId, productsLoaded: JSON.stringify(loadedProductIDs), productsRowTake: productTake, sort: sort, productTagIds: productTagIds, noOfCol: noOfCol },
                success: function (data) {
                    var background = $('#row-content-for-' + catId).find('.background');
                    background.remove();
                    $('#row-content-for-' + catId).append(data);
                    
                    // Show Or Hide Row Nav
                    var showNav = $('.CatProRow-' + catId).last().attr('is-show-row-nav');
                    if (showNav == "0") {
                        $('#row-nav-' + catId).hide();
                    } else {
                        $('#row-nav-' + catId).show();
                    }
                }
            });
        }