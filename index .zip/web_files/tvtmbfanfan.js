var tvtMbFanFan = {
    'loadCartMB': function (mbcart) {
        //        console.log(mbcart);
        var html = "";
        html += '                <table class="tvt-cart">';
        //html += '                    <tr class="tr_cart_header">';
        //html += '                        <td colspan="3">';
        //html += '                            <lable>' + mbcart.YourCart + '</lable>';
        //html += '                        </td>';
        //html += '                    </tr>';


        if (mbcart.numberProduct.length > 0) {
            html += '                    <tr>';
            html += '                        <td colspan="3">';

            var n = mbcart.data.length;
            for (var item in mbcart.data) {

                html += '                            <table class="tvt-cart-detail">';
                html += '                                <tr>';
                html += '                                    <td width="70px">';
                html += '                                        <a href="' + mbcart.data[item].link + '">';
                html += '                                            <img class="img-thumbnail" style="background-color:black;width:70px;" src="' + mbcart.data[item].img + '" alt="' + mbcart.data[item].title + '" title="' + mbcart.data[item].title + '" />';
                html += '                                        </a>';
                html += '                                    </td>';
                html += '                                    <td>';
                html += '                                        <a href="' + mbcart.data[item].link + '" style="text-align: left;display: inline;"><label>' + mbcart.data[item].title + '</label></a>';
                html += '                                    </td>';
                html += '                                    <td width="50px" style="text-align:center;">';
                html += '                                        <label> SL:</label></br>';
                html += '                                        <input onchange="MBUpdateQty(' + mbcart.data[item].idProduct + ',this.value)" style="text-align:center; width: 80%" type="text" size="2" value="' + mbcart.data[item].Quantity + '" />';
                html += '                                    </td>';
                html += '                                    <td width="70px" style="text-align:center;">';
                html += '                                        <span style="font-weight:normal;">' + mbcart.data[item].price + '</span>';
                html += '                                    </td>';
                html += '                                    <td style="width:40px;text-align:center;">';
                html += '                                        <a href="javascript:;" onclick="' + mbcart.data[item].linkdeleteOnclick + '">';
                html += '                                            <img class="img-thumbnail" style="background-color:black;width:30px;" src="' + mbcart.imgremove + '" alt="' + mbcart.data[item].title + '" title="' + mbcart.data[item].title + '" />';
                html += '                                        </a>';
                html += '                                    </td>';
                html += '                                </tr>';
                html += '                            </table>';
                html += (item >= (n - 1)) ? '' : '                            <hr class="mb_cart_line" />';
            }


            html += '                        </td>';
            html += '                    </tr>';
            html += '                    <tr class="tr_cart_bottom1">';
            html += '                        <td>';
            html += '                            <label>' + mbcart.numberKindOf + '</label>';
            html += '                        </td>';
            html += '                        <td>';
            html += '                            <label>' + mbcart.numberProduct + '</label>';
            html += '                        </td>';
            html += '                        <td>';
            html += '                            <label>' + mbcart.totalMony + '</label>';
            html += '                        </td>';
            html += '                    </tr>';
            html += '                    <tr class="tr_cart_bottom2">';
            html += '                        <td colspan="2"><a onclick="' + mbcart.onclickwishlist + '" href="javascript:;"><label class="pull-left bg_cart">' + mbcart.onclickwishlist_title + '</label></a></td>';
            html += '                        <td><a href="' + mbcart.urlbook + '"><label  class="pull-right bg_cart">' + mbcart.urlbook_title + '</label></a></td>';
            html += '                    </tr>';


        } else {
            html += '                        <td colspan="3">';
            html += '                               <p class="mb_cart_empty">' + mbcart.empty + '</p>';
            html += '                        </td';
        }
        html += '                </table>    ';

        $(".tvt-co-menu-cart").html(html);
        if (mbcart.numberProduct_Number > 0) {
            $(".mb_statecart").text("" + mbcart.numberProduct_Number);
            $(".mb_statecart").attr("style", "border:solid 1px red;");
        } else {
            $(".mb_statecart").text("0");
            $(".mb_statecart").attr("style", "border:solid 1px #fff;");
        }
        $(".tvt-co-menu-cart").attr("style", "max-height:" + ($(window).height() - 200) + "px;");
    },
    'curState': '',
    'checkClick': 0,
    'checkMenu': function (a) {
        if (this.curState == '') {
            this.curState = a;
            $('.' + a).click();
            return;
        }
        if (this.curState == a) {
            this.curState = '';
            $('.' + a).click();
            return;
        }
        $('.' + this.curState).click();
        $('.' + a).click();
        this.curState = a;
    },
    "initmenumb": function () {
        var m = '';
        if (mbmenuroot.menuroot1.length > 0) {
            //append into menu setting

            for (var k in menuItemGuide) {
                $('table.tvt_setting').append('<tr style="border-bottom:solid 1px #fff"><td class="mbitem_cart"><a style="text-transform:uppercase;" title="' + menuItemGuide[k].title + '" href="' + menuItemGuide[k].link + '">' + menuItemGuide[k].title + '</a></td></tr>');
            }
            m = ' <ul>';
            m += '<li>';
            m += '	<a href="javascript:;"  title="' + mbmenuroot.titlemenuHome + '">' + mbmenuroot.titlemenuHome + '</a>';
            m += '      <ul>';
            //            menuItemGuide
            for (var k in MbglobalFanfan.GuideMenu1) {
                m += '          <li>';
                m += '		 <a href="' + MbglobalFanfan.GuideMenu1[k].link + '" >' + MbglobalFanfan.GuideMenu1[k].title + '</a>';
                m += '         </li>';
            }
            m += '      </ul>';
            m += '</li>';
            for (var k in mbmenuroot.menuroot1) {

                m += '<li>';
                m += '	<a href="' + mbmenuroot.menuroot1[k].link + '"  title="' + mbmenuroot.menuroot1[k].title + '" >';
                m += mbmenuroot.menuroot1[k].title;
                m += '	</a>';
                if (mbmenuroot.root2[k].length > 0) {
                    m += '<ul>';
                    for (var k2 in mbmenuroot.root2[k]) {
                        m += '    <li>';
                        m += '		 <a href="' + mbmenuroot.root2[k][k2].link + '" >';
                        m += mbmenuroot.root2[k][k2].title;
                        m += '        </a>';
                        m += '    </li>';
                    }
                    m += '</ul>';
                }
                m += ' </li>';
            }
            m += '</ul>';
        }
        if (m.length > 0) {
            //if ($(window).width() < 991) {
                $("nav#menu").html(m);
                $('nav#menu').mmenu();
                $("div#mm-1 > div.mm-navbar > a.mm-title").first().html('<span class="glyphicon mb_icontvt_left"></span>' + MbglobalFanfan.MbPageBack);
            //}

        }
    },
    "inittvtwowsllider": function () {
        if (typeof tvtwowslider != 'undefined') {
            var m = "";
            m += '<div id="wowslider-container1">';
            m += '           <div class="ws_images"><ul>';

            if (tvtwowslider.data.length > 0) {
                for (var k in tvtwowslider.data) {
                    m += '<li><img  src="' + tvtwowslider.data[k].img + '" alt="' + tvtwowslider.data[k].title + '" title="" id="wows1_' + ((k == 0) ? "0" : k) + '"/></li>';
                }
            }
            m += '               </ul></div>';
            m += '           <div class="ws_bullets">';

            m += '           </div>';
            m += '';
            m += '           <div class="ws_shadow">';
            m += '           </div>';
            m += '       </div>	';
            if (tvtwowslider.js.length > 0) {
                for (var k in tvtwowslider.js) {
                    m += '<script type="text/javascript" src="' + tvtwowslider.js[k] + '"></script>';
                }
            }
            $(".tvtfanfanwowslider").html(m);
        }
    },
    "initSlider3Item": function () {
        if (typeof tvtwowslider3item != 'undefined') {


            if (tvtwowslider3item.length > 0) {
                var html = '<div class="item active">';
                var indexcount = 0;
                var strfirt = "";
                for (var k in tvtwowslider3item) {
                    //strfirt=(indexcount==1)?"active":"";
                    if ((indexcount > 0) && (indexcount % 3 === 0)) {
                        html += '        </div>';
                        html += '        <div class="item">';
                    }

                    html += '<div class="col-sm-4 col-xs-4">';
                    html += '   <a  href="' + tvtwowslider3item[k].link + '">';
                    html += '         <img src="' + tvtwowslider3item[k].img + '" class="img-responsive" />';
                    html += '   </a><br/>';
                    html += '   <a class="tvt_mbslider_title" href="' + tvtwowslider3item[k].link + '">';
                    html += '         <span>' + tvtwowslider3item[k].title + '</span>';
                    html += '   </a><br/>';
                    html += '   <span class="tvt_mbslider_price">' + ((tvtwowslider3item[k].type == 1) ? "" : (mbmenuroot.titlePriceItem3Wow + ": ")) + tvtwowslider3item[k].price + '</span>';
                    html += '</div>';
                    indexcount++;
                }


                if ($("#tvt_co_slider"))
                    $("#tvt_co_slider").html(html);

            }


        }
    },
    "getmenusetting": function () {
        var tmp = [];
        var html = '<ul>';

        $("table.tvt_setting tr > td.mbitem_cart").each(function (index) {
            html += '<li>' + $(this).html() + '</li>';
        });
        return html + "</ul>";
    }


};

$(document).ready(function () {
    tvtMbFanFan.initSlider3Item();
    tvtMbFanFan.inittvtwowsllider();
    tvtMbFanFan.initmenumb();

    //if ($(window).width() < 991) {
        $("#menu-right-setting").html(tvtMbFanFan.getmenusetting());
        $("#menu-right-setting").mmenu({
            offCanvas: {
                position: "right"
            }
        });
        $("div#mm-10 > div.mm-navbar > a.mm-title").first().html('<span class="glyphicon mb_icontvt_right"></span>' + MbglobalFanfan.MbPageBack);

        var API = $("#menu-right-setting").data("mmenu");
        $("div#mm-10 > div.mm-navbar > a.mm-title").first().click(function () {
            API.close();
        });
        var API1 = $("#menu").data("mmenu");
        $("div#mm-1 > div.mm-navbar > a.mm-title").first().click(function () {
            API1.close();
        });
    //s}
    //    $("ul li a.menu-lv1").click(function(){
    //        $("div.navbar-collapse-grid ul.main-menu li ul.dropdown-menu").hide();
    //        $($(this).parent().children()[1]).show();
    //    });

    //$(window).scroll(function () {
    //    var windscroll = $(window).scrollTop();
    //    if (windscroll >= 2) {
    //        $('div.tvtfanfanmenu').addClass('mbfanfan_fixed');
    //    } else {
    //        $('div.tvtfanfanmenu').removeClass('mbfanfan_fixed');
    //    }

    //}).scroll();






    co_cart_current = null;




    


//    -------------start document click-----------------
	
	 var clickHandler = "click touchstart";
    $(document).on(clickHandler, function (e) {
        if (!$('li.dropdown').is(e.target)
            && $('li.dropdown').has(e.target).length === 0
            && $('.open').has(e.target).length === 0) {
            var dropDownOpened = $(".dropdown.open");
            if (!dropDownOpened.hasClass('form')) {
                dropDownOpened.removeClass('open');
            } else {
                e.stopPropagation();
                return false;
            }
        } else if(e.target == null || e.target.tagName != 'A')
        {
            e.stopPropagation();
            return false;
        }
        
        var clickover = $(event.target);
        var $navbar = $(".navbar-collapse");
        var _opened = $navbar.hasClass("in");
        if (_opened === true && !clickover.hasClass("navbar-toggle")) {
            $navbar.collapse('hide');
        }
    });

    //$(document).on(clickHandler, function (e) {
    //    if ($(e.target).closest("div.add-to-cart-click .add-to-cart-box-wrraper").length === 0) {
    //        if (tvtMbFanFan.checkClick == 0) {
    //            //$('div.add-to-cart-click .add-to-cart-box-wrraper').removeClass("display-block");
    //        } else {
    //            tvtMbFanFan.checkClick = 0;
    //        }
    //    }
    //});

    //$("div.add-to-cart-click .add-to-cart-box-wrraper, div.tvt_co_search, div.tvt-co-menu-cart, ul#ui-id-1").on(clickHandler, function (e) {
    //    e.stopPropagation();

    //});
	
//    ----------------the end-------------------

});
